/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  CheckCircle, 
  ArrowLeft, 
  RefreshCw, 
  Sparkles, 
  ChevronRight,
  Target,
  Trophy,
  Info
} from 'lucide-react';
import { cn } from './lib/utils';
import { generateLadder, type LadderData, type Milestone } from './services/geminiService';

type Zone = {
  name: string;
  color: string;
  bg: string;
  border: string;
  text: string;
};

const ZONES: Record<string, Zone> = {
  bluff: { name: 'Bluff Zone', color: 'slate', bg: 'bg-slate-100', border: 'border-slate-200', text: 'text-slate-700' },
  familiar: { name: 'Familiar Zone', color: 'green', bg: 'bg-emerald-100', border: 'border-emerald-200', text: 'text-emerald-700' },
  practitioner: { name: 'Practitioner Zone', color: 'blue', bg: 'bg-blue-100', border: 'border-blue-200', text: 'text-blue-700' },
  expert: { name: 'Expert Zone', color: 'purple', bg: 'bg-purple-100', border: 'border-purple-200', text: 'text-purple-700' },
};

export default function App() {
  const [topic, setTopic] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [ladder, setLadder] = useState<LadderData | null>(null);
  const [checkedLevels, setCheckedLevels] = useState<Set<number>>(new Set());
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsLoading(true);
    setError(null);
    try {
      const data = await generateLadder(topic);
      setLadder(data);
      setCheckedLevels(new Set());
    } catch (err) {
      setError('Failed to generate ladder. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleLevel = (level: number) => {
    const newChecked = new Set(checkedLevels);
    if (newChecked.has(level)) {
      newChecked.delete(level);
    } else {
      newChecked.add(level);
    }
    setCheckedLevels(newChecked);
  };

  const score = useMemo(() => {
    let total = 0;
    checkedLevels.forEach(level => {
      if (level <= 3) total += 1;
      else if (level <= 7) total += 2;
      else total += 3;
    });
    return total;
  }, [checkedLevels]);

  const currentZone = useMemo(() => {
    if (score <= 4) return ZONES.bluff;
    if (score <= 9) return ZONES.familiar;
    if (score <= 15) return ZONES.practitioner;
    return ZONES.expert;
  }, [score]);

  const resetProgress = () => setCheckedLevels(new Set());
  const startOver = () => {
    setLadder(null);
    setTopic('');
    setCheckedLevels(new Set());
  };

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-900 selection:bg-blue-100">
      <div className="mx-auto max-w-2xl px-4 py-12 md:py-20">
        <AnimatePresence mode="wait">
          {!ladder && !isLoading ? (
            <motion.div
              key="landing"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8 text-center"
            >
              <div className="space-y-3">
                <motion.div 
                  initial={{ scale: 0.8 }}
                  animate={{ scale: 1 }}
                  className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600 text-white shadow-xl shadow-blue-200"
                >
                  <Target size={32} />
                </motion.div>
                <h1 className="text-4xl font-bold tracking-tight text-slate-900 md:text-5xl">
                  Insight Ladder
                </h1>
                <p className="mx-auto max-w-md text-lg text-slate-500">
                  Assess your depth of knowledge. Generate a 10-step proficiency ladder for any topic.
                </p>
              </div>

              <form onSubmit={handleGenerate} className="relative mx-auto max-w-md">
                <div className="relative">
                  <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="Enter a topic (e.g., Quantum Computing)"
                    className="w-full rounded-2xl border-none bg-white p-5 pr-36 text-lg shadow-lg ring-1 ring-slate-200 transition-all focus:ring-2 focus:ring-blue-500 focus:outline-none"
                    autoFocus
                  />
                  <button
                    type="submit"
                    disabled={!topic.trim()}
                    className="absolute right-2 top-2 bottom-2 rounded-xl bg-blue-600 px-6 font-semibold text-white shadow-md transition-all hover:bg-blue-700 active:scale-95 disabled:opacity-50 disabled:hover:bg-blue-600"
                  >
                    Generate
                  </button>
                </div>
                {error && (
                  <p className="mt-3 text-sm font-medium text-rose-500">{error}</p>
                )}
              </form>

              <div className="flex flex-wrap justify-center gap-2 text-sm text-slate-400">
                <span>Try:</span>
                {['Baking', 'React Hooks', 'Stoicism', 'Game Theory'].map((t) => (
                  <button
                    key={t}
                    onClick={() => setTopic(t)}
                    className="rounded-full bg-slate-200/50 px-3 py-1 transition-colors hover:bg-slate-200 hover:text-slate-600"
                  >
                    {t}
                  </button>
                ))}
              </div>
            </motion.div>
          ) : isLoading ? (
            <motion.div
              key="loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-8 py-12 text-center"
            >
              <div className="relative mx-auto h-24 w-24">
                <motion.div
                  animate={{ 
                    scale: [1, 1.2, 1],
                    rotate: [0, 180, 360]
                  }}
                  transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute inset-0 rounded-3xl bg-blue-100"
                />
                <div className="absolute inset-0 flex items-center justify-center text-blue-600">
                  <Sparkles size={40} className="animate-pulse" />
                </div>
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-semibold text-slate-900">Climbing the ladder...</h2>
                <p className="text-slate-500">Structuring milestones for "{topic}"</p>
              </div>
              <div className="mx-auto max-w-sm space-y-4">
                {[1, 2, 3].map(i => (
                  <div key={i} className="h-16 animate-pulse rounded-xl bg-white shadow-sm ring-1 ring-slate-100" />
                ))}
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="results"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-8"
            >
              <div className="flex items-center justify-between">
                <button
                  onClick={startOver}
                  className="flex items-center gap-2 text-sm font-medium text-slate-500 transition-colors hover:text-blue-600"
                >
                  <ArrowLeft size={16} />
                  Start Over
                </button>
                <div className="flex gap-2">
                  <button
                    onClick={resetProgress}
                    className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium text-slate-500 transition-colors hover:bg-slate-100 hover:text-slate-900"
                  >
                    <RefreshCw size={14} />
                    Reset
                  </button>
                </div>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <h2 className="text-3xl font-bold tracking-tight text-slate-900">{ladder?.topic}</h2>
                  <p className="text-slate-500">{ladder?.summary}</p>
                </div>

                <div className="sticky top-4 z-10 space-y-3 rounded-2xl bg-white/80 p-6 shadow-xl shadow-slate-200/50 ring-1 ring-slate-200 backdrop-blur-md">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <span className="text-xs font-bold tracking-wider text-slate-400 uppercase">Current Proficiency</span>
                      <div className="flex items-center gap-3">
                        <span className="text-3xl font-black text-slate-900">{score}</span>
                        <span className="text-slate-300">/</span>
                        <span className="text-lg font-bold text-slate-400">20</span>
                        <div className={cn(
                          "ml-2 flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold uppercase tracking-wide shadow-sm ring-1 ring-inset",
                          currentZone.bg, currentZone.text, currentZone.border
                        )}>
                          <Trophy size={12} />
                          {currentZone.name}
                        </div>
                      </div>
                    </div>
                    <div className="hidden text-right md:block">
                      <div className="text-xs font-medium text-slate-400">Milestones</div>
                      <div className="text-lg font-bold text-slate-700">{checkedLevels.size} / 10</div>
                    </div>
                  </div>
                  <div className="h-3 w-full overflow-hidden rounded-full bg-slate-100">
                    <motion.div
                      className={cn(
                        "h-full transition-all duration-500",
                        score <= 4 ? "bg-slate-400" : 
                        score <= 9 ? "bg-emerald-500" : 
                        score <= 15 ? "bg-blue-500" : "bg-purple-500"
                      )}
                      initial={{ width: 0 }}
                      animate={{ width: `${(score / 20) * 100}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                {ladder?.milestones.map((milestone, idx) => (
                  <MilestoneItem
                    key={milestone.level}
                    milestone={milestone}
                    isChecked={checkedLevels.has(milestone.level)}
                    onToggle={() => toggleLevel(milestone.level)}
                    index={idx}
                  />
                ))}
              </div>

              <div className="rounded-2xl bg-blue-50 p-6 text-center ring-1 ring-blue-100">
                <Info size={20} className="mx-auto mb-2 text-blue-500" />
                <p className="text-sm text-blue-700">
                  Be honest with your self-assessment. The goal is to identify gaps in your understanding, not just to reach the top.
                </p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

interface MilestoneItemProps {
  milestone: Milestone;
  isChecked: boolean;
  onToggle: () => void;
  index: number;
}

const MilestoneItem: React.FC<MilestoneItemProps> = ({ 
  milestone, 
  isChecked, 
  onToggle,
  index
}) => {
  const points = milestone.level <= 3 ? 1 : milestone.level <= 7 ? 2 : 3;

  return (
    <motion.button
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      onClick={onToggle}
      className={cn(
        "group relative flex w-full items-start gap-4 rounded-2xl bg-white p-5 text-left transition-all hover:shadow-md ring-1 ring-slate-200",
        isChecked ? "bg-blue-50/50 ring-blue-200" : "hover:ring-slate-300"
      )}
    >
      <div className={cn(
        "mt-1 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border-2 transition-all",
        isChecked 
          ? "border-blue-600 bg-blue-600 text-white" 
          : "border-slate-200 group-hover:border-slate-300"
      )}>
        {isChecked && <CheckCircle size={14} strokeWidth={3} />}
      </div>
      
      <div className="flex-1 space-y-1">
        <div className="flex items-center justify-between">
          <span className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">
            Level {milestone.level} • {milestone.type}
          </span>
          <span className={cn(
            "text-[10px] font-bold tracking-wider uppercase",
            isChecked ? "text-blue-600" : "text-slate-400"
          )}>
            {points} {points === 1 ? 'Point' : 'Points'}
          </span>
        </div>
        <p className={cn(
          "text-base leading-relaxed transition-colors",
          isChecked ? "font-medium text-slate-900" : "text-slate-600"
        )}>
          {milestone.text}
        </p>
      </div>
      
      <div className={cn(
        "absolute right-4 top-1/2 -translate-y-1/2 opacity-0 transition-all group-hover:translate-x-1 group-hover:opacity-100",
        isChecked ? "text-blue-400" : "text-slate-300"
      )}>
        <ChevronRight size={20} />
      </div>
    </motion.button>
  );
}
