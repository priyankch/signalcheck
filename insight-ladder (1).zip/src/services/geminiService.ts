import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface Milestone {
  level: number;
  type: string;
  text: string;
}

export interface LadderData {
  topic: string;
  summary: string;
  milestones: Milestone[];
}

export async function generateLadder(topic: string): Promise<LadderData> {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Generate a 10-step proficiency ladder for the topic: "${topic}".
    
    The ladder should progress from basic familiarity (Level 1) to expert judgment and meta-cognition (Level 10).
    Steps 1-3: Basic recognition and recall.
    Steps 4-7: Application and synthesis.
    Steps 8-10: Comparison, diagnosis, and meta-cognition.
    
    CRITICAL: Each milestone MUST be objective and verifiable. Avoid subjective verbs like "understand", "explain", "synthesize", or "integrate". 
    Instead, use concrete actions that can be checked off, such as:
    - "I can identify X when I see it."
    - "I can check for Z in a given scenario."
    - "I can perform the ABC task correctly."
    - "I can troubleshoot Y by doing Z."
    - "I can compare A and B based on specific criteria C."
    
    Each milestone must be written in the first person (e.g., "I can...").
    Provide the output in JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          topic: { type: Type.STRING },
          summary: { type: Type.STRING },
          milestones: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                level: { type: Type.NUMBER },
                type: { type: Type.STRING },
                text: { type: Type.STRING },
              },
              required: ["level", "type", "text"],
            },
          },
        },
        required: ["topic", "summary", "milestones"],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  return JSON.parse(text);
}
